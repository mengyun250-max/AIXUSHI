/* ============================================================
 * 克劳德 - AI卡牌叙事冒险
 * 卡组界面
 * ============================================================ */

/**
 * 卡组界面模块
 */
const DeckUI = {
  currentFilter: 'all',

  /**
   * 初始化卡组界面
   */
  init() {
    this.bindEvents();
  },

  /**
   * 绑定事件
   */
  bindEvents() {
    // 关闭卡组模态框按钮
    const closeDeckBtn = document.getElementById('btn-close-deck');
    if (closeDeckBtn) {
      closeDeckBtn.addEventListener('click', () => {
        this.hideModal();
      });
    }

    // 点击遮罩关闭
    if (DOM.elements.modalDeck) {
      DOM.elements.modalDeck.addEventListener('click', e => {
        if (e.target === DOM.elements.modalDeck) {
          this.hideModal();
        }
      });
    }

    // 卡组过滤标签
    const deckTabs = document.getElementById('deck-tabs');
    if (deckTabs) {
      deckTabs.querySelectorAll('.deck-tab').forEach(tab => {
        tab.addEventListener('click', e => {
          this.setFilter(e.target.dataset.filter);
        });
      });
    }

    // ESC键关闭
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && DOM.elements.modalDeck?.classList.contains('active')) {
        this.hideModal();
      }
    });
  },

  /**
   * 显示卡组模态框
   */
  showModal() {
    if (DOM.elements.modalDeck) {
      DOM.elements.modalDeck.classList.add('active');
      this.render();
    }
  },

  /**
   * 隐藏卡组模态框
   */
  hideModal() {
    if (DOM.elements.modalDeck) {
      DOM.elements.modalDeck.classList.remove('active');
    }
  },

  /**
   * 设置过滤器
   * @param {string} filter - 过滤类型
   */
  setFilter(filter) {
    this.currentFilter = filter;

    // 更新标签状态
    document.querySelectorAll('.deck-tab').forEach(tab => {
      tab.classList.remove('active');
      if (tab.dataset.filter === filter) {
        tab.classList.add('active');
      }
    });

    this.render();
  },

  /**
   * 渲染卡组
   */
  render() {
    const container = DOM.elements.modalDeckCards;
    if (!container) return;

    // 获取卡组（优先使用战斗中的卡组，否则生成新卡组）
    const deck = BattleState.deck.length > 0 ? BattleState.deck : CardSystem.generateInitialDeck(GameState.character);

    // 应用过滤
    let filteredDeck = deck;
    if (this.currentFilter !== 'all') {
      filteredDeck = deck.filter(card => card.type === this.currentFilter);
    }

    // 按类型和费用排序
    filteredDeck = this.sortCards(filteredDeck);

    // 渲染卡牌
    if (filteredDeck.length === 0) {
      container.innerHTML = '<p style="text-align:center;color:var(--ink-muted);padding:20px;">没有符合条件的卡牌</p>';
    } else {
      container.innerHTML = filteredDeck.map((card, index) => this.renderCardMini(card, index)).join('');

      // 绑定卡牌点击事件（显示详情）
      container.querySelectorAll('.deck-card-mini').forEach(cardEl => {
        cardEl.addEventListener('click', () => {
          const cardId = cardEl.dataset.id;
          this.showCardDetail(cardId, deck);
        });
      });
    }

    // 更新统计信息
    this.updateStats(deck);
  },

  /**
   * 渲染迷你卡牌
   * @param {Card} card - 卡牌对象
   * @param {number} index - 索引
   * @returns {string} - HTML字符串
   */
  renderCardMini(card, index) {
    const typeClass = card.type || '';
    return `
            <div class="deck-card-mini ${typeClass}" data-index="${index}" data-id="${card.id}">
                <div class="card-cost">${card.cost}</div>
                <div class="card-name">${card.name}</div>
            </div>
        `;
  },

  /**
   * 排序卡牌
   * @param {Array} cards - 卡牌数组
   * @returns {Array} - 排序后的卡牌数组
   */
  sortCards(cards) {
    return [...cards].sort((a, b) => {
      // 先按类型排序
      const typeOrder = { attack: 0, skill: 1, power: 2, status: 3, curse: 4 };
      const typeA = typeOrder[a.type] || 5;
      const typeB = typeOrder[b.type] || 5;
      if (typeA !== typeB) return typeA - typeB;

      // 再按费用排序
      if (a.cost !== b.cost) return a.cost - b.cost;

      // 最后按名称排序
      return a.name.localeCompare(b.name);
    });
  },

  /**
   * 更新统计信息
   * @param {Array} deck - 卡组
   */
  updateStats(deck) {
    // 统计各类型卡牌数量
    const stats = {
      total: deck.length,
      attack: deck.filter(c => c.type === 'attack').length,
      skill: deck.filter(c => c.type === 'skill').length,
      power: deck.filter(c => c.type === 'power').length,
    };

    // 可以在UI中显示这些统计信息
    console.log('卡组统计:', stats);
  },

  /**
   * 显示卡牌详情
   * @param {string} cardId - 卡牌ID
   * @param {Array} deck - 卡组
   */
  showCardDetail(cardId, deck) {
    const card = deck.find(c => c.id === cardId);
    if (!card) return;

    // 创建详情弹窗
    const detailHtml = `
            <div class="card-detail-overlay" id="card-detail-overlay">
                <div class="card-detail glass-panel">
                    <div class="game-card ${card.type}" style="width:180px;height:250px;margin:0 auto 20px;">
                        <div class="card-cost">${card.cost}</div>
                        <div class="card-name">${card.name}</div>
                        <div class="card-type">${card.getTypeLabel ? card.getTypeLabel() : card.type}</div>
                        <div class="card-desc">${card.description}</div>
                    </div>
                    <div class="card-detail-info">
                        <p><strong>稀有度:</strong> ${this.getRarityLabel(card.rarity)}</p>
                        ${card.exhaust ? '<p><strong>消耗:</strong> 使用后移除</p>' : ''}
                        ${card.ethereal ? '<p><strong>虚无:</strong> 回合结束时消耗</p>' : ''}
                        ${card.innate ? '<p><strong>固有:</strong> 战斗开始时在手牌中</p>' : ''}
                    </div>
                    <button class="btn btn-secondary btn-small" onclick="DeckUI.hideCardDetail()">关闭</button>
                </div>
            </div>
        `;

    // 添加到DOM
    const existingOverlay = document.getElementById('card-detail-overlay');
    if (existingOverlay) {
      existingOverlay.remove();
    }

    document.body.insertAdjacentHTML('beforeend', detailHtml);

    // 点击遮罩关闭
    const overlay = document.getElementById('card-detail-overlay');
    overlay.addEventListener('click', e => {
      if (e.target === overlay) {
        this.hideCardDetail();
      }
    });
  },

  /**
   * 隐藏卡牌详情
   */
  hideCardDetail() {
    const overlay = document.getElementById('card-detail-overlay');
    if (overlay) {
      overlay.remove();
    }
  },

  /**
   * 获取稀有度标签
   * @param {string} rarity - 稀有度
   * @returns {string} - 中文标签
   */
  getRarityLabel(rarity) {
    const labels = {
      basic: '基础',
      common: '普通',
      uncommon: '罕见',
      rare: '稀有',
    };
    return labels[rarity] || '未知';
  },

  /**
   * 获取卡组概览HTML
   * @returns {string} - HTML字符串
   */
  getOverviewHTML() {
    const deck = BattleState.deck.length > 0 ? BattleState.deck : CardSystem.generateInitialDeck(GameState.character);

    return `
            <div class="deck-overview glass-panel">
                <div class="deck-header">
                    <h3 class="deck-title">我的卡组</h3>
                    <span class="deck-count">${deck.length}</span>
                </div>
                <div class="deck-cards">
                    ${deck
                      .slice(0, 6)
                      .map((card, i) => this.renderCardMini(card, i))
                      .join('')}
                    ${deck.length > 6 ? '<div class="deck-card-mini more">+' + (deck.length - 6) + '</div>' : ''}
                </div>
            </div>
        `;
  },
};

// 添加卡牌详情样式
const deckStyles = document.createElement('style');
deckStyles.textContent = `
    .card-detail-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 2000;
        animation: fadeIn 0.2s ease;
    }

    .card-detail {
        padding: 30px;
        max-width: 300px;
        text-align: center;
    }

    .card-detail-info {
        margin-bottom: 20px;
        text-align: left;
        font-size: 0.9rem;
    }

    .card-detail-info p {
        margin: 5px 0;
    }
`;
document.head.appendChild(deckStyles);

// 导出
window.DeckUI = DeckUI;
